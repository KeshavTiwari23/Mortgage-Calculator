import React from 'react';

export default function App() {
  return (
    <div className='min-h-screen flex items-center justify-center'>
      <h1 className='text-2xl font-bold'>Mortgage Calculator Wireframe</h1>
      <p className='text-gray-600 mt-2'>Replace this with your main component code.</p>
    </div>
  );
}
